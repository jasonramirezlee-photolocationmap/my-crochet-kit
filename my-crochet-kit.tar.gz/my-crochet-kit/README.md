# 🧶 My Crochet Kit

The ultimate offline-first Progressive Web App (PWA) for crocheters! Track patterns, count rows, manage your yarn stash, and never lose your place again.

## ✨ Features

### Free Tier: "First Stitch"
- ✅ Up to 10 projects
- ✅ Basic row counter
- ✅ Pattern import (PDF)
- ✅ Basic yarn stash tracking
- ✅ Full offline mode
- ✅ Ad-supported

### Pro Tier: "Hooked" - $9.99/month or $89.99/year
- ✅ Unlimited projects
- ✅ Advanced counters with custom alerts
- ✅ Pattern annotations
- ✅ Time tracking for pricing
- ✅ Photo progress tracking
- ✅ Ad-free experience
- ✅ Priority support

### Expert Tier: "Master Maker" - $19.99/month or $179.99/year
- ✅ Everything in Pro tier
- ✅ Advanced pricing calculator (for sellers)
- ✅ Pattern creation tools
- ✅ Video tutorial integration
- ✅ Premium community features
- ✅ Cloud backup with version history
- ✅ Export patterns to sell

## 🎨 Design

Built with a warm, yarn-inspired color palette that crocheters will love:
- **Cream** - Soft background like natural wool
- **Dusty Rose** - Primary actions
- **Sage Green** - Success states
- **Lavender** - Accents
- **Warm Brown** - Text (like wooden hooks!)
- **Deep Purple** - Premium features

## 🚀 Tech Stack

- **Next.js 14** - React framework with App Router
- **TypeScript** - Type safety for fewer bugs
- **Tailwind CSS** - Beautiful, responsive styling
- **PWA (next-pwa)** - Offline-first, installable app
- **Supabase** - Backend, database, and auth (to be added)
- **Stripe** - Payment processing (to be added)

## 📦 Getting Started

### Prerequisites
- Node.js 18 or higher
- npm or yarn

### Installation

1. **Clone this repository**
```bash
git clone https://github.com/YOUR-USERNAME/my-crochet-kit.git
cd my-crochet-kit
```

2. **Install dependencies**
```bash
npm install
```

3. **Run the development server**
```bash
npm run dev
```

4. **Open your browser**
Navigate to [http://localhost:3000](http://localhost:3000)

### Build for Production

```bash
npm run build
npm start
```

## 🌐 Deployment to Vercel

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repository
5. Click "Deploy" (Vercel auto-detects Next.js!)

Your app will be live in under a minute! 🎉

## 📱 PWA Features

- ✅ **Offline-first** - Works without internet
- ✅ **Installable** - Add to home screen on mobile
- ✅ **Fast** - Cached for instant loading
- ✅ **Reliable** - Never lose your data

## 🗺️ Roadmap

### Phase 1: Foundation ✅ (DONE!)
- [x] Project structure
- [x] PWA configuration
- [x] Beautiful UI with yarn-inspired colors
- [x] Basic routing and navigation

### Phase 2: Core Features (NEXT!)
- [ ] Pattern library (view, import, organize)
- [ ] Row counter (the most-used feature!)
- [ ] Project tracking with progress
- [ ] Yarn stash management

### Phase 3: Advanced Features
- [ ] Offline sync & storage
- [ ] Authentication (Supabase)
- [ ] Pricing calculator for sellers
- [ ] Health reminders (prevent hand pain!)
- [ ] Photo progress tracking
- [ ] Pattern annotations

### Phase 4: Premium Features
- [ ] Stripe integration for subscriptions
- [ ] Advanced pricing calculator
- [ ] Pattern creation tools
- [ ] Community features
- [ ] Video tutorials

## 🤝 Contributing

This is a solo project, but feedback and suggestions are welcome!

## 📄 License

Copyright © 2025 My Crochet Kit. All rights reserved.

## 💜 Made with Love

Built by a developer for the amazing crochet community. Happy hooking! 🧶
